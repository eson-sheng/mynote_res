				</div>
			</div>
			<div class="c_btm"></div>
		</div>
	</div>
</div>

<script src="../../static/js/jquery.js" type="text/javascript"></script>
<script src="./img/install.js" type="text/javascript"></script>
</body>
</html>
