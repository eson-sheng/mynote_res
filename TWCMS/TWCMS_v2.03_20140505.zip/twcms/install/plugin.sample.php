<?php
return array (
  'tw_links' =>
  array (
    'enable' => 1,
  ),
  'editor_um' =>
  array (
    'enable' => 1,
  ),
);
