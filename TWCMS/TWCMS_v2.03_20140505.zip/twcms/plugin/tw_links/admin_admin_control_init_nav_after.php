<?php
defined('TWCMS_PATH') or exit;

$this->_navs[1]['links-index'] = array('name'=>'友情链接', 'p'=>'plugin');
