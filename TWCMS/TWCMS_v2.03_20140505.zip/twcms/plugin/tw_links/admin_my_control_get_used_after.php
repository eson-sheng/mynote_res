<?php
defined('TWCMS_PATH') or exit;

$arr[] = array('name'=>'友情链接', 'url'=>'links-index', 'imgsrc'=>'../twcms/plugin/tw_links/show.jpg');
