<?php
return array(
	'name' => '友情链接',	// 插件名
	'brief' => '简单的友情链接插件，只支持文字链接，更有益搜索引擎优化。',
	'version' => '1.0.0',			// 插件版本
	'cms_version' => '2.0.0',		// 插件支持的 TWCMS 版本
	'update' => '2013-10-27',		// 插件最近更新
	'author' => '空城',				// 插件作者
	'authorurl' => 'http://blog.520.at',	// 插件作者主页
	'setting' => 'links-index',		// 插件设置URL
);
