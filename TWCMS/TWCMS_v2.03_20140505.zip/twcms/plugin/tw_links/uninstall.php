<?php
defined('KONG_PATH') || exit;

$this->kv->delete('tw_links');
