<?php header('HTTP/1.1 404 Not Found');?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>404 Not Found</title>
</head>

<body>
<h1>404 Not Found</h1>
</body>
</html>