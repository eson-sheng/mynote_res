<div id="About">
<h2>关于 LyFM PHP文件管理器</h2>
<div class="content">
	<p>首先，请谨慎使用该程序，当你对其有任何怀疑，或觉得有任何不妥时，请立即停止使用，或许你的感觉是对的。</p>
	<p>作者博客:<a href="http://www.loveyu.org">http://www.loveyu.org</a>，这绝对是一个不错的反馈地址。</p>
	<p>程序主页:<a href="http://www.loveyu.net/LyFm">http://www.loveyu.net/LyFm</a></p>
	<p>免责：作者不对你所做的任何失误操作进行负责，不会要求搜集使用则的任何信息，但会对程序版本进行统计。</p>
</div>
<div class="license">
	<h3>The MIT License (MIT)</h3>
	<p>Copyright (c) 2013 Loveyu</p>
	<p>Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:</p>
	<p>The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.</p>
	<p>THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.</p>
</div>
</div>